-- =====================================================================
-- SSAS (SmartSummerAgricultureSystem) database
-- How to use: open phpMyAdmin > Import > choose this file > Go.
-- It creates the database "ssas_db", all tables and starter data.
-- WARNING: running it again resets the database to the starter state.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS ssas_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ssas_db;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS feedback;
DROP TABLE IF EXISTS recommendation_requests;
DROP TABLE IF EXISTS supplier_varieties;
DROP TABLE IF EXISTS variety_districts;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS varieties;
DROP TABLE IF EXISTS crops;
DROP TABLE IF EXISTS districts;
DROP TABLE IF EXISTS officers;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- Officer/Admin  (the only people who log in; farmers do not)
-- ---------------------------------------------------------------------
CREATE TABLE officers (
  officer_id    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  full_name     VARCHAR(100) NOT NULL,
  email         VARCHAR(150) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('admin','officer') NOT NULL DEFAULT 'officer',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (officer_id),
  UNIQUE KEY uq_officers_email (email)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- District
-- ---------------------------------------------------------------------
CREATE TABLE districts (
  district_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(60) NOT NULL,
  province    VARCHAR(40) NOT NULL,
  PRIMARY KEY (district_id),
  UNIQUE KEY uq_districts_name (name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Crop (beans, cassava, ...)  - a crop has many varieties
-- ---------------------------------------------------------------------
CREATE TABLE crops (
  crop_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name    VARCHAR(60) NOT NULL,
  PRIMARY KEY (crop_id),
  UNIQUE KEY uq_crops_name (name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Variety
-- ---------------------------------------------------------------------
CREATE TABLE varieties (
  variety_id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  crop_id           INT UNSIGNED NOT NULL,
  name              VARCHAR(100) NOT NULL,
  drought_tolerance ENUM('low','medium','high') NOT NULL DEFAULT 'medium',
  expected_yield    DECIMAL(6,1) NULL COMMENT 'tonnes per hectare',
  maturity_days     SMALLINT UNSIGNED NULL,
  water_need        ENUM('low','medium','high') NOT NULL DEFAULT 'medium',
  notes             TEXT NULL,
  is_sample         TINYINT(1) NOT NULL DEFAULT 0,
  created_by        INT UNSIGNED NULL,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (variety_id),
  KEY idx_varieties_crop (crop_id),
  CONSTRAINT fk_varieties_crop FOREIGN KEY (crop_id) REFERENCES crops (crop_id) ON DELETE CASCADE,
  CONSTRAINT fk_varieties_officer FOREIGN KEY (created_by) REFERENCES officers (officer_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Where a variety is recommended. A variety with NO rows here is
-- treated as suitable for every district.
CREATE TABLE variety_districts (
  variety_id  INT UNSIGNED NOT NULL,
  district_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (variety_id, district_id),
  CONSTRAINT fk_vd_variety  FOREIGN KEY (variety_id)  REFERENCES varieties (variety_id) ON DELETE CASCADE,
  CONSTRAINT fk_vd_district FOREIGN KEY (district_id) REFERENCES districts (district_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Supplier  (located in one district, can stock many varieties)
-- ---------------------------------------------------------------------
CREATE TABLE suppliers (
  supplier_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(120) NOT NULL,
  phone       VARCHAR(30) NULL,
  location    VARCHAR(150) NULL,
  district_id INT UNSIGNED NOT NULL,
  is_sample   TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (supplier_id),
  KEY idx_suppliers_district (district_id),
  CONSTRAINT fk_suppliers_district FOREIGN KEY (district_id) REFERENCES districts (district_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE supplier_varieties (
  supplier_id INT UNSIGNED NOT NULL,
  variety_id  INT UNSIGNED NOT NULL,
  PRIMARY KEY (supplier_id, variety_id),
  CONSTRAINT fk_sv_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers (supplier_id) ON DELETE CASCADE,
  CONSTRAINT fk_sv_variety  FOREIGN KEY (variety_id)  REFERENCES varieties (variety_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- RecommendationRequest  (one row per farmer request; no farmer identity)
-- ---------------------------------------------------------------------
CREATE TABLE recommendation_requests (
  request_id   INT UNSIGNED NOT NULL AUTO_INCREMENT,
  crop_id      INT UNSIGNED NOT NULL,
  district_id  INT UNSIGNED NOT NULL,
  sector       VARCHAR(60) NULL,
  variety_id   INT UNSIGNED NULL COMMENT 'variety that was recommended, NULL if none found',
  found        TINYINT(1) NOT NULL DEFAULT 0,
  requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (request_id),
  KEY idx_req_date (requested_at),
  KEY idx_req_variety (variety_id),
  KEY idx_req_district (district_id),
  KEY idx_req_crop (crop_id),
  CONSTRAINT fk_req_crop     FOREIGN KEY (crop_id)     REFERENCES crops (crop_id)         ON DELETE CASCADE,
  CONSTRAINT fk_req_district FOREIGN KEY (district_id) REFERENCES districts (district_id) ON DELETE CASCADE,
  CONSTRAINT fk_req_variety  FOREIGN KEY (variety_id)  REFERENCES varieties (variety_id)  ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Feedback  (the "give feedback" use case)
-- ---------------------------------------------------------------------
CREATE TABLE feedback (
  feedback_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  request_id  INT UNSIGNED NULL,
  variety_id  INT UNSIGNED NULL,
  outcome     ENUM('worked','partly','not_helpful') NOT NULL,
  comment     VARCHAR(500) NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (feedback_id),
  KEY idx_feedback_request (request_id),
  CONSTRAINT fk_fb_request FOREIGN KEY (request_id) REFERENCES recommendation_requests (request_id) ON DELETE SET NULL,
  CONSTRAINT fk_fb_variety FOREIGN KEY (variety_id) REFERENCES varieties (variety_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
-- STARTER DATA
-- =====================================================================

INSERT INTO districts (name, province) VALUES
 ('Gasabo','Kigali City'), ('Kicukiro','Kigali City'), ('Nyarugenge','Kigali City'),
 ('Gisagara','Southern'), ('Huye','Southern'), ('Kamonyi','Southern'), ('Muhanga','Southern'),
 ('Nyamagabe','Southern'), ('Nyanza','Southern'), ('Nyaruguru','Southern'), ('Ruhango','Southern'),
 ('Karongi','Western'), ('Ngororero','Western'), ('Nyabihu','Western'), ('Nyamasheke','Western'),
 ('Rubavu','Western'), ('Rusizi','Western'), ('Rutsiro','Western'),
 ('Burera','Northern'), ('Gakenke','Northern'), ('Gicumbi','Northern'), ('Musanze','Northern'), ('Rulindo','Northern'),
 ('Bugesera','Eastern'), ('Gatsibo','Eastern'), ('Kayonza','Eastern'), ('Kirehe','Eastern'),
 ('Ngoma','Eastern'), ('Nyagatare','Eastern'), ('Rwamagana','Eastern');

INSERT INTO crops (name) VALUES
 ('Beans'), ('Cassava'), ('Irish potatoes'), ('Groundnuts'), ('Maize'), ('Sweet potatoes');

-- Varieties.
-- Records marked is_sample = 1 are DEMONSTRATION data only. Replace them with
-- real RAB-approved varieties through the officer pages. The other records
-- are variety names reported in RAB farmer trials; confirm every figure with
-- RAB before real farmers rely on it.
INSERT INTO varieties
 (crop_id, name, drought_tolerance, expected_yield, maturity_days, water_need, notes, is_sample) VALUES
 ((SELECT crop_id FROM crops WHERE name='Cassava'), 'Nsizebashonje', 'high', 35.0, NULL, 'low',
  'Reported as climate-resilient in RAB farmer trials, with much higher yield than older cassava. Rating is indicative: confirm with RAB.', 0),
 ((SELECT crop_id FROM crops WHERE name='Cassava'), 'Biseruka', 'high', 35.0, NULL, 'low',
  'Reported as climate-resilient in RAB farmer trials. Rating is indicative: confirm with RAB.', 0),
 ((SELECT crop_id FROM crops WHERE name='Irish potatoes'), 'Cyerekezo', 'medium', 30.0, NULL, 'medium',
  'Ranked highest for productivity and pest/disease resistance in RAB farmer trials. Drought rating is indicative: confirm with RAB.', 0),
 ((SELECT crop_id FROM crops WHERE name='Maize'), 'RHM1407', 'medium', NULL, NULL, 'medium',
  'Hybrid reported to outperform traditional maize in RAB trials. Confirm details with RAB.', 0),
 ((SELECT crop_id FROM crops WHERE name='Maize'), 'RHM1409', 'medium', NULL, NULL, 'medium',
  'Hybrid reported to outperform traditional maize in RAB trials. Confirm details with RAB.', 0),
 ((SELECT crop_id FROM crops WHERE name='Beans'), 'Sample dry-season bean', 'high', 1.8, 75, 'low',
  'DEMONSTRATION RECORD. Replace with a RAB-approved bean variety.', 1),
 ((SELECT crop_id FROM crops WHERE name='Groundnuts'), 'Sample dry-season groundnut', 'high', 2.0, 100, 'low',
  'DEMONSTRATION RECORD. Replace with a RAB-approved groundnut variety.', 1);
-- Sweet potatoes has no variety on purpose, so you can see the "no match" screen.

-- Example of a district-specific variety: the sample bean is suggested for these districts only.
INSERT INTO variety_districts (variety_id, district_id)
SELECT v.variety_id, d.district_id FROM varieties v JOIN districts d
WHERE v.name = 'Sample dry-season bean'
  AND d.name IN ('Huye','Nyanza','Gisagara','Kamonyi','Muhanga','Ruhango','Bugesera','Kayonza','Kirehe','Nyagatare');

-- Sample suppliers (fake names, no phone numbers). Replace with real ones.
INSERT INTO suppliers (name, phone, location, district_id, is_sample) VALUES
 ('Sample Seed Cooperative', NULL, 'Near the main market',  (SELECT district_id FROM districts WHERE name='Huye'),      1),
 ('Sample Agro-dealer',      NULL, 'Town centre',           (SELECT district_id FROM districts WHERE name='Musanze'),   1),
 ('Sample Farmers Cooperative', NULL, 'Cooperative office', (SELECT district_id FROM districts WHERE name='Nyagatare'), 1),
 ('Sample Seed Shop',        NULL, 'Kimironko',             (SELECT district_id FROM districts WHERE name='Gasabo'),    1);

INSERT INTO supplier_varieties (supplier_id, variety_id)
SELECT s.supplier_id, v.variety_id FROM suppliers s JOIN varieties v
WHERE (s.name='Sample Seed Cooperative'    AND v.name IN ('Nsizebashonje','Biseruka','Sample dry-season bean'))
   OR (s.name='Sample Agro-dealer'         AND v.name IN ('Cyerekezo','Nsizebashonje','RHM1407'))
   OR (s.name='Sample Farmers Cooperative' AND v.name IN ('RHM1407','RHM1409','Sample dry-season bean','Sample dry-season groundnut'))
   OR (s.name='Sample Seed Shop'           AND v.name IN ('Biseruka','Cyerekezo','Sample dry-season groundnut'));

-- No officer accounts are created here. The FIRST person who signs up on
-- admin/signup.php becomes the admin.
