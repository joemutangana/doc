SSAS - SmartSummerAgricultureSystem
===================================

WHAT YOU NEED
  XAMPP (or WAMP) with Apache and MySQL running. PHP 7.4 or newer.

SETUP (5 steps)
  1. Open XAMPP and click Start next to Apache and MySQL.

  2. Open phpMyAdmin:  http://localhost/phpmyadmin
     Click "Import" > "Choose file" > select  ssas.sql  > click "Import" at the bottom.
     This creates the database "ssas_db", the tables and some starter data.
     (Importing it again later resets everything to the starter state.)

  3. OPTIONAL, for presentations: import  optional_demo_requests.sql  the same way.
     It adds about 100 made-up farmer requests so the officer dashboard has numbers.

  4. Extract this zip into your XAMPP folder so that index.php sits directly here:
        C:\xampp\htdocs\ssas\index.php
     (the folder must be named "ssas")

  5. Open your browser:
        Farmer site :  http://localhost/ssas/
        Officer area:  http://localhost/ssas/admin/login.php


FIRST OFFICER ACCOUNT
  Go to  http://localhost/ssas/admin/signup.php
  Officer access code:  SSAS-2026   (change it in config.php)
  The FIRST account you create becomes the Admin. Later accounts are Officers.
  Farmers never need an account.


WHAT EACH PAGE DOES
  Farmer site
    index.php            Home page: choose crop + district (+ optional sector)
    result.php           Best dry-season variety, its facts, and seed suppliers
    feedback.php         Saves the "Did this help?" answer

  Officer area (admin/)
    login.php, signup.php, logout.php
    index.php            Overview: totals, requests per variety and district,
                         crops farmers asked for that have no variety yet
    requests.php         All farmer requests, with filters and CSV download
    varieties.php        List, edit and delete varieties
    variety_form.php     Add / edit a variety and choose the districts it suits
    suppliers.php        List, edit and delete suppliers
    supplier_form.php    Add / edit a supplier and the varieties it stocks
    feedback.php         Farmer feedback

  Other
    config.php           Database login and the officer access code
    includes/            Shared code (database, login, layout)
    assets/              Styles and small script


IMPORTANT - SAMPLE DATA
  Records marked "Sample" are for demonstration only (the sample beans and
  groundnuts and the four sample suppliers). Replace them with real,
  RAB-approved varieties and real suppliers from the officer area.
  The cassava, potato and maize names come from RAB trial reports; confirm
  their details with RAB before farmers rely on them.
  Sweet potatoes has no variety on purpose, so you can see the "no match" page.


HOW THE RECOMMENDATION WORKS
  1. The farmer picks a crop and a district.
  2. SSAS looks for varieties of that crop that suit the district. A variety with
     no districts ticked suits every district.
  3. The best one is shown first: highest drought tolerance, then highest yield.
  4. Suppliers that stock it are listed, the farmer's own district first.
  5. One anonymous row (crop, district, date, variety offered) is saved.
     That is what the officer dashboard counts.


IF SOMETHING GOES WRONG
  "SSAS cannot reach its database"
      MySQL is not started, ssas.sql was not imported, or the user/password in
      config.php is different from your MySQL (XAMPP default: root, no password).
  Blank page or 404
      The folder must be htdocs\ssas and index.php must be directly inside it.
  Page looks plain, no fonts
      The fonts load from the internet. Offline, the site uses your computer's
      normal fonts and still works.
