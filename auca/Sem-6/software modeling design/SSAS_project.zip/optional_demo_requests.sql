-- OPTIONAL. Run this AFTER ssas.sql if you want the officer dashboard to
-- show numbers while you test or present the project.
-- It adds about 100 made-up farmer requests over the last 30 days.
-- To remove them later, run:  DELETE FROM recommendation_requests;

USE ssas_db;

INSERT INTO recommendation_requests (crop_id, district_id, variety_id, found, requested_at)
SELECT t.crop_id, t.district_id, t.vid, IF(t.vid IS NULL, 0, 1), t.ts
FROM (
  SELECT c.crop_id,
         d.district_id,
         (SELECT v.variety_id FROM varieties v
           WHERE v.crop_id = c.crop_id ORDER BY v.variety_id LIMIT 1) AS vid,
         NOW() - INTERVAL FLOOR(RAND() * 30) DAY
               - INTERVAL FLOOR(RAND() * 86400) SECOND AS ts
  FROM crops c
  JOIN districts d
  JOIN (SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3) m
  WHERE d.name IN ('Huye','Musanze','Nyagatare','Gasabo','Bugesera','Rubavu')
) t;
