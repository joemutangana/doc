<?php
/**
 * SSAS settings. Defaults match a normal XAMPP / WAMP install.
 * Change these only if your MySQL setup is different.
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'ssas_db');
define('DB_USER', 'root');
define('DB_PASS', '');          // XAMPP root usually has no password

// Anyone creating an officer account must type this code on the signup page.
// Change it, then share it only with real agriculture officers.
define('SIGNUP_CODE', 'SSAS-2026');

define('APP_NAME', 'SSAS');
define('APP_FULL_NAME', 'SmartSummerAgricultureSystem');
