<?php
require_once __DIR__ . '/includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('index.php');
}
csrf_verify();

$pdo       = db();
$requestId = (int) (isset($_POST['request_id']) ? $_POST['request_id'] : 0);
$outcome   = isset($_POST['outcome']) ? (string) $_POST['outcome'] : '';
$comment   = trim(isset($_POST['comment']) ? (string) $_POST['comment'] : '');
$comment   = $comment === '' ? null : text_cut($comment, 500);

$stmt = $pdo->prepare('SELECT request_id, variety_id FROM recommendation_requests WHERE request_id = ?');
$stmt->execute(array($requestId));
$req = $stmt->fetch();

if (!$req) {
    redirect('index.php');
}

if (!in_array($outcome, array('worked', 'partly', 'not_helpful'), true)) {
    flash('error', 'Please choose one of the answers.');
    redirect('result.php?r=' . $requestId);
}

if (!empty($_SESSION['fb_done'][$requestId])) {
    redirect('result.php?r=' . $requestId);
}

$insert = $pdo->prepare('INSERT INTO feedback (request_id, variety_id, outcome, comment) VALUES (?, ?, ?, ?)');
$insert->execute(array($requestId, $req['variety_id'], $outcome, $comment));

$_SESSION['fb_done'][$requestId] = true;
flash('success', 'Thank you. Your feedback helps officers improve the advice.');
redirect('result.php?r=' . $requestId);
