<?php
/**
 * Loaded by every page: settings, session, database, small helpers.
 */
require_once __DIR__ . '/../config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name('ssas_session');
    session_set_cookie_params(array('httponly' => true, 'samesite' => 'Lax'));
    session_start();
}

/* ---- base URL, so links work whether the site is at /ssas or at the root ---- */
$__dir = str_replace('\\', '/', dirname(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '/'));
if (substr($__dir, -6) === '/admin') {
    $__dir = substr($__dir, 0, -6);
}
define('BASE_URL', rtrim($__dir, '/'));

/* ---- output + navigation helpers ---- */
function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url($path = '')
{
    return BASE_URL . '/' . ltrim($path, '/');
}

function redirect($path)
{
    header('Location: ' . url($path));
    exit;
}


/* ---- text length / cutting that also works if PHP has no mbstring ---- */
function text_len($text)
{
    if (function_exists('mb_strlen')) {
        return mb_strlen($text, 'UTF-8');
    }
    return preg_match_all('/./us', $text, $m);
}

function text_cut($text, $max)
{
    if (function_exists('mb_substr')) {
        return mb_substr($text, 0, $max, 'UTF-8');
    }
    return preg_match('/^.{0,' . (int) $max . '}/us', $text, $m) ? $m[0] : '';
}

/* ---- database ---- */
function db()
{
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }
    try {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER,
            DB_PASS,
            array(
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            )
        );
    } catch (PDOException $ex) {
        http_response_code(500);
        echo '<!doctype html><meta charset="utf-8"><title>SSAS: database problem</title>'
           . '<body style="font-family:system-ui,sans-serif;max-width:560px;margin:12vh auto;padding:0 20px;line-height:1.5">'
           . '<h1 style="font-size:1.4rem">SSAS cannot reach its database</h1>'
           . '<p>Check these three things:</p><ol>'
           . '<li>MySQL is running in XAMPP (or WAMP).</li>'
           . '<li>You imported <code>ssas.sql</code> in phpMyAdmin.</li>'
           . '<li>The user and password in <code>config.php</code> are correct.</li></ol></body>';
        exit;
    }
    return $pdo;
}

/* ---- flash messages (shown once after a redirect) ---- */
function flash($type, $message)
{
    $_SESSION['flash'][] = array('type' => $type, 'message' => $message);
}

function take_flashes()
{
    $items = isset($_SESSION['flash']) ? $_SESSION['flash'] : array();
    unset($_SESSION['flash']);
    return $items;
}

/* ---- CSRF protection for every form that changes data ---- */
function csrf_token()
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field()
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_verify()
{
    $sent = isset($_POST['_csrf']) ? $_POST['_csrf'] : '';
    if (!hash_equals(csrf_token(), (string) $sent)) {
        http_response_code(400);
        echo 'The form expired. Go back, refresh the page and try again.';
        exit;
    }
}

/* ---- officer / admin login ---- */
function current_officer()
{
    static $cache = false;
    if ($cache !== false) {
        return $cache;
    }
    $cache = null;
    if (!empty($_SESSION['officer_id'])) {
        $stmt = db()->prepare('SELECT officer_id, full_name, email, role FROM officers WHERE officer_id = ?');
        $stmt->execute(array($_SESSION['officer_id']));
        $row = $stmt->fetch();
        $cache = $row ? $row : null;
    }
    return $cache;
}

function require_login()
{
    if (current_officer() === null) {
        redirect('admin/login.php');
    }
}

/* ---- small formatting helpers shared by pages ---- */
function level_label($level)
{
    $map = array('low' => 'Low', 'medium' => 'Medium', 'high' => 'High');
    return isset($map[$level]) ? $map[$level] : '';
}

function level_number($level)
{
    $map = array('low' => 1, 'medium' => 2, 'high' => 3);
    return isset($map[$level]) ? $map[$level] : 0;
}

/** Three small bars that fill up with the level (low = 1, high = 3). */
function meter($level)
{
    $n = level_number($level);
    $html = '<span class="meter meter-' . e($level) . '" role="img" aria-label="' . e(level_label($level)) . '">';
    for ($i = 1; $i <= 3; $i++) {
        $html .= '<i class="' . ($i <= $n ? 'on' : '') . '"></i>';
    }
    return $html . '</span>';
}

function fmt_yield($value)
{
    if ($value === null || $value === '') {
        return 'Not recorded';
    }
    return rtrim(rtrim(number_format((float) $value, 1, '.', ''), '0'), '.') . ' t/ha';
}

function fmt_days($value)
{
    return ($value === null || $value === '') ? 'Not recorded' : (int) $value . ' days';
}

function fmt_date($value)
{
    return $value ? date('d M Y, H:i', strtotime($value)) : '';
}

/* ---- data helpers used by the farmer pages ---- */
function all_crops()
{
    return db()->query('SELECT crop_id, name FROM crops ORDER BY name')->fetchAll();
}

function all_districts()
{
    return db()->query('SELECT district_id, name, province FROM districts ORDER BY province, name')->fetchAll();
}

function districts_by_province()
{
    $grouped = array();
    foreach (all_districts() as $d) {
        $grouped[$d['province']][] = $d;
    }
    return $grouped;
}

/**
 * Varieties for a crop that suit a district, best first.
 * A variety with no district list counts as suitable everywhere.
 */
function find_varieties($cropId, $districtId)
{
    $sql = "SELECT v.*
              FROM varieties v
             WHERE v.crop_id = :crop
               AND ( NOT EXISTS (SELECT 1 FROM variety_districts a WHERE a.variety_id = v.variety_id)
                     OR EXISTS (SELECT 1 FROM variety_districts b
                                 WHERE b.variety_id = v.variety_id AND b.district_id = :district) )
             ORDER BY FIELD(v.drought_tolerance, 'high', 'medium', 'low'),
                      (v.expected_yield IS NULL), v.expected_yield DESC, v.name";
    $stmt = db()->prepare($sql);
    $stmt->execute(array(':crop' => $cropId, ':district' => $districtId));
    return $stmt->fetchAll();
}

/** Suppliers stocking a variety, the farmer's own district first. */
function find_suppliers($varietyId, $districtId, $limit = 6)
{
    $sql = "SELECT s.*, d.name AS district_name, (s.district_id = :district) AS same_district
              FROM suppliers s
              JOIN supplier_varieties sv ON sv.supplier_id = s.supplier_id
              JOIN districts d ON d.district_id = s.district_id
             WHERE sv.variety_id = :variety
             ORDER BY same_district DESC, s.name
             LIMIT " . (int) $limit;
    $stmt = db()->prepare($sql);
    $stmt->execute(array(':district' => $districtId, ':variety' => $varietyId));
    return $stmt->fetchAll();
}
