<?php
/**
 * Layout for the farmer-facing pages.
 * Usage:  public_header('Page title', 'home');  ...content...  public_footer();
 */

function font_links()
{
    return '<link rel="preconnect" href="https://fonts.googleapis.com">'
         . '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
         . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700&amp;family=Nunito+Sans:wght@400;600;700&amp;display=swap">';
}

function brand_mark()
{
    return '<svg class="brand-sun" viewBox="0 0 32 32" aria-hidden="true">'
         . '<circle cx="16" cy="16" r="7" fill="currentColor"/>'
         . '<g stroke="currentColor" stroke-width="2.2" stroke-linecap="round">'
         . '<path d="M16 2.5v4M16 25.5v4M2.5 16h4M25.5 16h4M6.5 6.5l2.8 2.8M22.7 22.7l2.8 2.8M25.5 6.5l-2.8 2.8M9.3 22.7l-2.8 2.8"/>'
         . '</g></svg>';
}

function public_header($title, $bodyClass = '')
{
    $officer = current_officer();
    ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> | <?= e(APP_NAME) ?></title>
<?= font_links() ?>
<link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="public <?= e($bodyClass) ?>">
<a class="skip-link" href="#main">Skip to content</a>
<header class="site-nav">
  <div class="container nav-row">
    <a class="brand" href="<?= e(url('index.php')) ?>">
      <?= brand_mark() ?>
      <span class="brand-name"><?= e(APP_NAME) ?></span>
    </a>
    <nav class="nav-links" aria-label="Main">
      <a href="<?= e(url('index.php')) ?>">Find a variety</a>
      <?php if ($officer): ?>
        <a class="nav-pill" href="<?= e(url('admin/index.php')) ?>">Officer area</a>
      <?php else: ?>
        <a class="nav-pill" href="<?= e(url('admin/login.php')) ?>">Officer login</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main id="main">
<?php
    foreach (take_flashes() as $f) {
        echo '<div class="container"><div class="notice notice-' . e($f['type']) . '" role="status">' . e($f['message']) . '</div></div>';
    }
}

function public_footer()
{
    ?>
</main>
<footer class="site-footer">
  <div class="container">
    <p><strong><?= e(APP_FULL_NAME) ?></strong></p>
    <p>Variety records are entered and checked by agriculture officers. Always confirm seed details with your district agronomist before planting.</p>
  </div>
</footer>
<script src="<?= e(url('assets/js/app.js')) ?>"></script>
</body>
</html>
<?php
}
