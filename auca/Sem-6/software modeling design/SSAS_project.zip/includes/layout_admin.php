<?php
/**
 * Layout for the officer/admin pages (sidebar + content).
 * Usage:  admin_header('Title', 'varieties');  ...content...  admin_footer();
 */
require_once __DIR__ . '/layout_public.php';

function admin_header($title, $active = '')
{
    $officer = current_officer();
    $items = array(
        'overview'  => array('Overview',  'admin/index.php'),
        'requests'  => array('Requests',  'admin/requests.php'),
        'varieties' => array('Varieties', 'admin/varieties.php'),
        'suppliers' => array('Suppliers', 'admin/suppliers.php'),
        'feedback'  => array('Feedback',  'admin/feedback.php'),
    );
    ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> | <?= e(APP_NAME) ?> officer area</title>
<?= font_links() ?>
<link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="admin">
<a class="skip-link" href="#main">Skip to content</a>
<div class="admin-shell">
  <aside class="sidebar" id="sidebar">
    <a class="brand brand-light" href="<?= e(url('admin/index.php')) ?>">
      <?= brand_mark() ?>
      <span class="brand-name"><?= e(APP_NAME) ?></span>
    </a>
    <nav class="side-nav" aria-label="Officer menu">
      <?php foreach ($items as $key => $item): ?>
        <a href="<?= e(url($item[1])) ?>" class="<?= $key === $active ? 'is-active' : '' ?>"><?= e($item[0]) ?></a>
      <?php endforeach; ?>
    </nav>
    <div class="side-foot">
      <a href="<?= e(url('index.php')) ?>" class="side-link">View farmer site</a>
      <div class="who">
        <span class="who-name"><?= e($officer ? $officer['full_name'] : '') ?></span>
        <span class="who-role"><?= e($officer ? ($officer['role'] === 'admin' ? 'Admin' : 'Officer') : '') ?></span>
      </div>
      <a href="<?= e(url('admin/logout.php')) ?>" class="side-link">Log out</a>
    </div>
  </aside>
  <div class="admin-main">
    <header class="admin-top">
      <button class="menu-btn" type="button" aria-controls="sidebar" aria-expanded="false" data-menu>Menu</button>
      <h1><?= e($title) ?></h1>
    </header>
    <main id="main" class="admin-content">
<?php
    foreach (take_flashes() as $f) {
        echo '<div class="notice notice-' . e($f['type']) . '" role="status">' . e($f['message']) . '</div>';
    }
}

function admin_footer()
{
    ?>
    </main>
  </div>
</div>
<script src="<?= e(url('assets/js/app.js')) ?>"></script>
</body>
</html>
<?php
}

/** Layout for the login / signup pages (no sidebar). */
function auth_header($title)
{
    ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> | <?= e(APP_NAME) ?></title>
<?= font_links() ?>
<link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="auth">
<main id="main" class="auth-wrap">
  <a class="brand brand-light" href="<?= e(url('index.php')) ?>">
    <?= brand_mark() ?>
    <span class="brand-name"><?= e(APP_NAME) ?></span>
  </a>
  <div class="auth-card">
<?php
    foreach (take_flashes() as $f) {
        echo '<div class="notice notice-' . e($f['type']) . '" role="status">' . e($f['message']) . '</div>';
    }
}

function auth_footer()
{
    ?>
  </div>
  <p class="auth-back"><a href="<?= e(url('index.php')) ?>">Back to the farmer site</a></p>
</main>
</body>
</html>
<?php
}
