<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout_public.php';

$pdo = db();

/* ------------------------------------------------------------------
   Step 1. A farmer submitted the form: check it, find the best variety,
   save one anonymous request row, then redirect to the result address.
   (Redirecting means a page refresh does not count the request twice.)
------------------------------------------------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $cropId     = (int) (isset($_POST['crop_id']) ? $_POST['crop_id'] : 0);
    $districtId = (int) (isset($_POST['district_id']) ? $_POST['district_id'] : 0);
    $sector     = trim(isset($_POST['sector']) ? (string) $_POST['sector'] : '');
    $sector     = $sector === '' ? null : text_cut($sector, 60);

    $cropOk = $pdo->prepare('SELECT 1 FROM crops WHERE crop_id = ?');
    $cropOk->execute(array($cropId));
    $districtOk = $pdo->prepare('SELECT 1 FROM districts WHERE district_id = ?');
    $districtOk->execute(array($districtId));

    if (!$cropOk->fetchColumn() || !$districtOk->fetchColumn()) {
        flash('error', 'Please choose a crop and a district.');
        redirect('index.php');
    }

    $matches   = find_varieties($cropId, $districtId);
    $varietyId = $matches ? (int) $matches[0]['variety_id'] : null;

    $insert = $pdo->prepare(
        'INSERT INTO recommendation_requests (crop_id, district_id, sector, variety_id, found)
         VALUES (?, ?, ?, ?, ?)'
    );
    $insert->execute(array($cropId, $districtId, $sector, $varietyId, $varietyId ? 1 : 0));

    redirect('result.php?r=' . (int) $pdo->lastInsertId());
}

/* ------------------------------------------------------------------
   Step 2. Show the result for a saved request.
------------------------------------------------------------------- */
$requestId = (int) (isset($_GET['r']) ? $_GET['r'] : 0);
$stmt = $pdo->prepare(
    'SELECT r.*, c.name AS crop_name, d.name AS district_name
       FROM recommendation_requests r
       JOIN crops c ON c.crop_id = r.crop_id
       JOIN districts d ON d.district_id = r.district_id
      WHERE r.request_id = ?'
);
$stmt->execute(array($requestId));
$req = $stmt->fetch();

if (!$req) {
    redirect('index.php');
}

$matches   = find_varieties((int) $req['crop_id'], (int) $req['district_id']);
$best      = $matches ? $matches[0] : null;
$others    = $matches ? array_slice($matches, 1) : array();
$suppliers = $best ? find_suppliers((int) $best['variety_id'], (int) $req['district_id']) : array();

$alreadyRated = !empty($_SESSION['fb_done'][$requestId]);

public_header($req['crop_name'] . ' in ' . $req['district_name']);
?>
<section class="result-head">
  <div class="container">
    <a class="back-link" href="<?= e(url('index.php')) ?>">Search again</a>
    <h1><?= e($req['crop_name']) ?> in <?= e($req['district_name']) ?></h1>
    <?php if (!empty($req['sector'])): ?>
      <p class="muted">Sector: <?= e($req['sector']) ?></p>
    <?php endif; ?>
  </div>
</section>

<div class="container result-body">
<?php if ($best): ?>

  <article class="best">
    <p class="best-label">Best match for dry weather</p>
    <h2 class="variety-name">
      <?= e($best['name']) ?>
      <?php if ($best['is_sample']): ?><span class="tag tag-sample">Sample record</span><?php endif; ?>
    </h2>

    <div class="tolerance">
      <?= meter($best['drought_tolerance']) ?>
      <span><strong><?= e(level_label($best['drought_tolerance'])) ?></strong> drought tolerance</span>
    </div>

    <dl class="facts">
      <div><dt>Expected yield</dt><dd><?= e(fmt_yield($best['expected_yield'])) ?></dd></div>
      <div><dt>Ready to harvest</dt><dd><?= e(fmt_days($best['maturity_days'])) ?></dd></div>
      <div><dt>Water needed</dt><dd><?= e(level_label($best['water_need'])) ?></dd></div>
    </dl>

    <?php if (!empty($best['notes'])): ?>
      <p class="notes"><?= e($best['notes']) ?></p>
    <?php endif; ?>
  </article>

  <section class="panel" aria-labelledby="sup-title">
    <h2 id="sup-title">Where to get the seed</h2>
    <?php if ($suppliers): ?>
      <ul class="supplier-list">
        <?php foreach ($suppliers as $s): ?>
          <li>
            <div>
              <strong><?= e($s['name']) ?></strong>
              <?php if ($s['same_district']): ?><span class="tag tag-near">In your district</span><?php endif; ?>
              <?php if ($s['is_sample']): ?><span class="tag tag-sample">Sample</span><?php endif; ?>
              <div class="muted"><?= e($s['district_name']) ?><?= $s['location'] ? ', ' . e($s['location']) : '' ?></div>
            </div>
            <?php if (!empty($s['phone'])): ?>
              <a class="btn btn-ghost" href="tel:<?= e(preg_replace('/[^0-9+]/', '', $s['phone'])) ?>">Call <?= e($s['phone']) ?></a>
            <?php else: ?>
              <span class="muted">No phone listed</span>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <p class="empty">No supplier has been listed for this variety yet. Ask your district agronomist where to find it.</p>
    <?php endif; ?>
  </section>

  <?php if ($others): ?>
  <section class="panel" aria-labelledby="oth-title">
    <h2 id="oth-title">Other varieties of <?= e(strtolower($req['crop_name'])) ?></h2>
    <ul class="other-list">
      <?php foreach ($others as $o): ?>
        <li>
          <strong><?= e($o['name']) ?></strong>
          <span class="tolerance-sm"><?= meter($o['drought_tolerance']) ?> <?= e(level_label($o['drought_tolerance'])) ?> drought tolerance</span>
          <span class="muted"><?= e(fmt_yield($o['expected_yield'])) ?></span>
        </li>
      <?php endforeach; ?>
    </ul>
  </section>
  <?php endif; ?>

<?php else: ?>

  <article class="best best-empty">
    <h2 class="variety-name">No variety recorded yet</h2>
    <p>Officers have not added a dry-season variety of <?= e(strtolower($req['crop_name'])) ?> for <?= e($req['district_name']) ?>.</p>
    <p>Your request was counted, so officers can see that farmers need this crop. In the meantime, ask your district agronomist, or try another crop.</p>
    <a class="btn btn-sun" href="<?= e(url('index.php')) ?>">Try another crop</a>
  </article>

<?php endif; ?>

<?php if ($best): ?>
  <section class="panel feedback" aria-labelledby="fb-title">
    <h2 id="fb-title">Did this help?</h2>
    <?php if ($alreadyRated): ?>
      <p class="empty">Thank you. Your answer has been saved.</p>
    <?php else: ?>
      <form method="post" action="<?= e(url('feedback.php')) ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="request_id" value="<?= (int) $requestId ?>">
        <fieldset class="choice-row">
          <legend class="sr-only">How did it go?</legend>
          <label class="choice"><input type="radio" name="outcome" value="worked" required><span>I planted it and it worked</span></label>
          <label class="choice"><input type="radio" name="outcome" value="partly"><span>It worked partly</span></label>
          <label class="choice"><input type="radio" name="outcome" value="not_helpful"><span>This was not helpful</span></label>
        </fieldset>
        <label for="comment">Anything officers should know? <span class="optional">(optional)</span></label>
        <textarea id="comment" name="comment" rows="3" maxlength="500"></textarea>
        <button class="btn btn-primary" type="submit">Send feedback</button>
      </form>
    <?php endif; ?>
  </section>
<?php endif; ?>
</div>
<?php public_footer(); ?>
