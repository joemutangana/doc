<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout_public.php';

$crops = all_crops();
$provinces = districts_by_province();

$coverage = db()->query(
    'SELECT c.name, COUNT(v.variety_id) AS total
       FROM crops c LEFT JOIN varieties v ON v.crop_id = c.crop_id
      GROUP BY c.crop_id, c.name ORDER BY c.name'
)->fetchAll();

public_header('Find a dry-season variety', 'home');
?>
<section class="hero">
  <div class="hero-art" aria-hidden="true">
    <svg viewBox="0 0 1440 640" preserveAspectRatio="xMidYMax slice" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <path id="hill-a" d="M0 430 C150 370 300 392 440 420 C600 452 730 356 900 366 C1080 378 1230 440 1440 392 L1440 720 L0 720 Z"/>
        <path id="top-a"  d="M0 430 C150 370 300 392 440 420 C600 452 730 356 900 366 C1080 378 1230 440 1440 392" fill="none"/>
        <clipPath id="clip-a"><use href="#hill-a"/></clipPath>

        <path id="hill-b" d="M0 490 C200 440 360 480 520 478 C700 476 820 418 1000 438 C1180 458 1300 508 1440 460 L1440 720 L0 720 Z"/>
        <path id="top-b"  d="M0 490 C200 440 360 480 520 478 C700 476 820 418 1000 438 C1180 458 1300 508 1440 460" fill="none"/>
        <clipPath id="clip-b"><use href="#hill-b"/></clipPath>

        <path id="hill-c" d="M0 548 C180 508 380 548 560 538 C760 526 900 488 1100 508 C1260 522 1360 556 1440 536 L1440 720 L0 720 Z"/>
        <path id="top-c"  d="M0 548 C180 508 380 548 560 538 C760 526 900 488 1100 508 C1260 522 1360 556 1440 536" fill="none"/>
        <clipPath id="clip-c"><use href="#hill-c"/></clipPath>
      </defs>

      <!-- the dry-season sun, resting on the horizon -->
      <circle cx="745" cy="400" r="215" fill="#F2A813" fill-opacity=".10"/>
      <circle cx="745" cy="400" r="156" fill="#F2A813" fill-opacity=".18"/>
      <circle cx="745" cy="400" r="104" fill="#F2A813"/>

      <g transform="translate(0,60)">
        <use href="#hill-a" fill="#C5D9A8"/>
        <g clip-path="url(#clip-a)" stroke="#fff" stroke-opacity=".45" stroke-width="2" fill="none">
          <use href="#top-a" y="16"/><use href="#top-a" y="34"/><use href="#top-a" y="54"/><use href="#top-a" y="76"/>
        </g>

        <use href="#hill-b" fill="#86B56E"/>
        <g clip-path="url(#clip-b)" stroke="#fff" stroke-opacity=".32" stroke-width="2" fill="none">
          <use href="#top-b" y="16"/><use href="#top-b" y="34"/><use href="#top-b" y="54"/><use href="#top-b" y="76"/>
        </g>

        <use href="#hill-c" fill="#2F6B3E"/>
        <g clip-path="url(#clip-c)" stroke="#fff" stroke-opacity=".22" stroke-width="2" fill="none">
          <use href="#top-c" y="14"/><use href="#top-c" y="30"/><use href="#top-c" y="48"/>
        </g>
      </g>
    </svg>
  </div>

  <div class="container hero-grid">
    <div class="hero-copy">
      <h1>Keep your land growing when the rains stop.</h1>
      <p class="lead">Choose your crop and your district. SSAS shows the variety that handles dry weather best, and where you can get the seed.</p>
    </div>

    <form class="finder" method="post" action="<?= e(url('result.php')) ?>">
      <?= csrf_field() ?>
      <h2>Find my variety</h2>

      <label for="crop_id">Crop</label>
      <select id="crop_id" name="crop_id" required>
        <option value="">Choose a crop</option>
        <?php foreach ($crops as $c): ?>
          <option value="<?= (int) $c['crop_id'] ?>"><?= e($c['name']) ?></option>
        <?php endforeach; ?>
      </select>

      <label for="district_id">District</label>
      <select id="district_id" name="district_id" required>
        <option value="">Choose your district</option>
        <?php foreach ($provinces as $province => $list): ?>
          <optgroup label="<?= e($province) ?>">
            <?php foreach ($list as $d): ?>
              <option value="<?= (int) $d['district_id'] ?>"><?= e($d['name']) ?></option>
            <?php endforeach; ?>
          </optgroup>
        <?php endforeach; ?>
      </select>

      <label for="sector">Sector <span class="optional">(optional)</span></label>
      <input id="sector" name="sector" type="text" maxlength="60" autocomplete="off" placeholder="For example: Tumba">

      <button class="btn btn-sun btn-block" type="submit">Find my variety</button>
      <p class="fine">No account needed. Your request is counted without your name, so officers can see which seed farmers are asking for.</p>
    </form>
  </div>
</section>

<section class="section">
  <div class="container">
    <h2 class="section-title">How it works</h2>
    <ol class="steps">
      <li>
        <span class="step-no">1</span>
        <h3>Choose your crop and district</h3>
        <p>Tell SSAS what you want to plant and where your land is.</p>
      </li>
      <li>
        <span class="step-no">2</span>
        <h3>See the variety for dry weather</h3>
        <p>You get the variety that copes best with low rain, with its expected yield and time to harvest.</p>
      </li>
      <li>
        <span class="step-no">3</span>
        <h3>Contact a seed supplier</h3>
        <p>Suppliers in your own district are shown first, with their phone number and location.</p>
      </li>
    </ol>
  </div>
</section>

<section class="section section-tint">
  <div class="container">
    <h2 class="section-title">Crops in the system</h2>
    <ul class="crop-list">
      <?php foreach ($coverage as $row): ?>
        <li>
          <span class="crop-name"><?= e($row['name']) ?></span>
          <span class="crop-count"><?= (int) $row['total'] === 0 ? 'No variety yet' : (int) $row['total'] . ((int) $row['total'] === 1 ? ' variety' : ' varieties') ?></span>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>
</section>
<?php public_footer(); ?>
