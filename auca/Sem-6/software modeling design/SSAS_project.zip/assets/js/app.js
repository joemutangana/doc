/* Small helpers for SSAS. The site still works if JavaScript is off. */
(function () {
  // Confirm before deleting.
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (!window.confirm(form.getAttribute('data-confirm'))) {
        event.preventDefault();
      }
    });
  });

  // Filter dropdowns submit as soon as they change.
  document.querySelectorAll('select[data-autosubmit]').forEach(function (select) {
    select.addEventListener('change', function () {
      select.form.submit();
    });
  });

  // "Tick all" and "Clear" buttons on the district and variety pickers.
  var picker = document.querySelector('.district-picker');
  if (picker) {
    var boxes = picker.querySelectorAll('input[type="checkbox"]');
    var all = picker.querySelector('[data-check-all]');
    var none = picker.querySelector('[data-check-none]');
    if (all) { all.addEventListener('click', function () { boxes.forEach(function (b) { b.checked = true; }); }); }
    if (none) { none.addEventListener('click', function () { boxes.forEach(function (b) { b.checked = false; }); }); }
  }

  // Mobile menu for the officer area.
  var menuBtn = document.querySelector('[data-menu]');
  var sidebar = document.getElementById('sidebar');
  if (menuBtn && sidebar) {
    menuBtn.addEventListener('click', function () {
      var open = sidebar.classList.toggle('is-open');
      menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }
})();
