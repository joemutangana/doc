<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout_admin.php';
require_login();

$pdo = db();

$total      = (int) $pdo->query('SELECT COUNT(*) FROM recommendation_requests')->fetchColumn();
$week       = (int) $pdo->query('SELECT COUNT(*) FROM recommendation_requests WHERE requested_at >= NOW() - INTERVAL 7 DAY')->fetchColumn();
$unmatched  = (int) $pdo->query('SELECT COUNT(*) FROM recommendation_requests WHERE found = 0')->fetchColumn();
$varCount   = (int) $pdo->query('SELECT COUNT(*) FROM varieties')->fetchColumn();
$supCount   = (int) $pdo->query('SELECT COUNT(*) FROM suppliers')->fetchColumn();

/* Requests per variety (the countRequests(varietyId) idea from the class diagram) */
$byVariety = $pdo->query(
    'SELECT v.variety_id, v.name, c.name AS crop, COUNT(r.request_id) AS n
       FROM varieties v
       JOIN crops c ON c.crop_id = v.crop_id
       LEFT JOIN recommendation_requests r ON r.variety_id = v.variety_id
      GROUP BY v.variety_id, v.name, c.name
      ORDER BY n DESC, v.name LIMIT 8'
)->fetchAll();

/* Requests per district */
$byDistrict = $pdo->query(
    'SELECT d.name, COUNT(r.request_id) AS n
       FROM districts d
       JOIN recommendation_requests r ON r.district_id = d.district_id
      GROUP BY d.district_id, d.name
      ORDER BY n DESC, d.name LIMIT 8'
)->fetchAll();

/* Demand with no variety to offer: where officers should add records */
$gaps = $pdo->query(
    'SELECT c.name AS crop, d.name AS district, COUNT(*) AS n
       FROM recommendation_requests r
       JOIN crops c ON c.crop_id = r.crop_id
       JOIN districts d ON d.district_id = r.district_id
      WHERE r.found = 0
      GROUP BY c.crop_id, c.name, d.district_id, d.name
      ORDER BY n DESC LIMIT 6'
)->fetchAll();

$recent = $pdo->query(
    'SELECT r.requested_at, r.found, c.name AS crop, d.name AS district, v.name AS variety
       FROM recommendation_requests r
       JOIN crops c ON c.crop_id = r.crop_id
       JOIN districts d ON d.district_id = r.district_id
       LEFT JOIN varieties v ON v.variety_id = r.variety_id
      ORDER BY r.requested_at DESC, r.request_id DESC LIMIT 8'
)->fetchAll();

$fb = $pdo->query('SELECT outcome, COUNT(*) AS n FROM feedback GROUP BY outcome')->fetchAll(PDO::FETCH_KEY_PAIR);
$fbTotal = array_sum($fb);

function bar_width($n, $rows)
{
    $max = 1;
    foreach ($rows as $r) {
        $max = max($max, (int) $r['n']);
    }
    return round(((int) $n / $max) * 100);
}

admin_header('Overview', 'overview');
?>
<section class="stats" aria-label="Totals">
  <div class="stat"><span class="stat-num"><?= $total ?></span><span class="stat-label">Requests in total</span></div>
  <div class="stat"><span class="stat-num"><?= $week ?></span><span class="stat-label">Requests in the last 7 days</span></div>
  <div class="stat <?= $unmatched ? 'stat-warn' : '' ?>"><span class="stat-num"><?= $unmatched ?></span><span class="stat-label">Requests with no variety to offer</span></div>
  <div class="stat"><span class="stat-num"><?= $varCount ?></span><span class="stat-label">Varieties</span></div>
  <div class="stat"><span class="stat-num"><?= $supCount ?></span><span class="stat-label">Suppliers</span></div>
</section>

<?php if ($total === 0): ?>
  <div class="panel empty-state">
    <h2>No requests yet</h2>
    <p>When farmers use the home page, their requests will appear here. To see the dashboard with example numbers, import <code>optional_demo_requests.sql</code> in phpMyAdmin.</p>
  </div>
<?php else: ?>

<div class="grid-2">
  <section class="panel">
    <h2>Requests per variety</h2>
    <ul class="bars">
      <?php foreach ($byVariety as $r): ?>
        <li>
          <div class="bar-head"><span><?= e($r['name']) ?> <span class="muted">(<?= e($r['crop']) ?>)</span></span><strong><?= (int) $r['n'] ?></strong></div>
          <div class="bar"><span style="width: <?= bar_width($r['n'], $byVariety) ?>%"></span></div>
        </li>
      <?php endforeach; ?>
    </ul>
  </section>

  <section class="panel">
    <h2>Requests per district</h2>
    <ul class="bars">
      <?php foreach ($byDistrict as $r): ?>
        <li>
          <div class="bar-head"><span><?= e($r['name']) ?></span><strong><?= (int) $r['n'] ?></strong></div>
          <div class="bar"><span style="width: <?= bar_width($r['n'], $byDistrict) ?>%"></span></div>
        </li>
      <?php endforeach; ?>
    </ul>
  </section>
</div>

<div class="grid-2">
  <section class="panel">
    <h2>Farmers asked, but no variety exists</h2>
    <?php if ($gaps): ?>
      <p class="muted">Add a variety for these crops and districts first.</p>
      <table class="table">
        <thead><tr><th>Crop</th><th>District</th><th class="num">Requests</th></tr></thead>
        <tbody>
        <?php foreach ($gaps as $g): ?>
          <tr><td><?= e($g['crop']) ?></td><td><?= e($g['district']) ?></td><td class="num"><?= (int) $g['n'] ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <a class="btn btn-ghost" href="<?= e(url('admin/variety_form.php')) ?>">Add a variety</a>
    <?php else: ?>
      <p class="empty">Every request so far had a variety to offer.</p>
    <?php endif; ?>
  </section>

  <section class="panel">
    <h2>Farmer feedback</h2>
    <?php if ($fbTotal): ?>
      <ul class="bars">
        <?php
        $labels = array('worked' => 'It worked', 'partly' => 'It worked partly', 'not_helpful' => 'Not helpful');
        foreach ($labels as $key => $label):
            $n = isset($fb[$key]) ? (int) $fb[$key] : 0; ?>
          <li>
            <div class="bar-head"><span><?= e($label) ?></span><strong><?= $n ?></strong></div>
            <div class="bar"><span style="width: <?= $fbTotal ? round($n / $fbTotal * 100) : 0 ?>%"></span></div>
          </li>
        <?php endforeach; ?>
      </ul>
      <a class="btn btn-ghost" href="<?= e(url('admin/feedback.php')) ?>">Read all feedback</a>
    <?php else: ?>
      <p class="empty">No feedback yet.</p>
    <?php endif; ?>
  </section>
</div>

<section class="panel">
  <div class="panel-head"><h2>Latest requests</h2><a href="<?= e(url('admin/requests.php')) ?>">See all requests</a></div>
  <div class="table-wrap">
    <table class="table">
      <thead><tr><th>When</th><th>Crop</th><th>District</th><th>Variety offered</th></tr></thead>
      <tbody>
      <?php foreach ($recent as $r): ?>
        <tr>
          <td><?= e(fmt_date($r['requested_at'])) ?></td>
          <td><?= e($r['crop']) ?></td>
          <td><?= e($r['district']) ?></td>
          <td><?= $r['found'] ? e($r['variety']) : '<span class="tag tag-warn">None</span>' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>

<?php endif; ?>
<?php admin_footer(); ?>
