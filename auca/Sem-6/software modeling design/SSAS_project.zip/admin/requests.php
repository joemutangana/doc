<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout_admin.php';
require_login();

$pdo = db();

/* ---- filters (all optional) ---- */
$crop     = (int) (isset($_GET['crop']) ? $_GET['crop'] : 0);
$district = (int) (isset($_GET['district']) ? $_GET['district'] : 0);
$found    = isset($_GET['found']) ? (string) $_GET['found'] : '';
$from     = isset($_GET['from']) ? (string) $_GET['from'] : '';
$to       = isset($_GET['to']) ? (string) $_GET['to'] : '';

$where  = array();
$params = array();
if ($crop)     { $where[] = 'r.crop_id = ?';     $params[] = $crop; }
if ($district) { $where[] = 'r.district_id = ?'; $params[] = $district; }
if ($found === '1' || $found === '0') { $where[] = 'r.found = ?'; $params[] = (int) $found; }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) { $where[] = 'r.requested_at >= ?'; $params[] = $from . ' 00:00:00'; }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))   { $where[] = 'r.requested_at <= ?'; $params[] = $to . ' 23:59:59'; }
$whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

$baseSql = 'FROM recommendation_requests r
            JOIN crops c ON c.crop_id = r.crop_id
            JOIN districts d ON d.district_id = r.district_id
            LEFT JOIN varieties v ON v.variety_id = r.variety_id' . $whereSql;

/* ---- CSV download of the filtered list ---- */
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $stmt = $pdo->prepare('SELECT r.requested_at, c.name AS crop, d.name AS district, r.sector, v.name AS variety, r.found ' . $baseSql . ' ORDER BY r.requested_at DESC');
    $stmt->execute($params);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="ssas_requests_' . date('Ymd') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF"); // so Excel reads accents correctly
    fputcsv($out, array('Date and time', 'Crop', 'District', 'Sector', 'Variety offered', 'Variety found'));
    while ($row = $stmt->fetch()) {
        fputcsv($out, array($row['requested_at'], $row['crop'], $row['district'], $row['sector'], $row['variety'], $row['found'] ? 'yes' : 'no'));
    }
    fclose($out);
    exit;
}

/* ---- paging ---- */
$perPage = 25;
$cnt = $pdo->prepare('SELECT COUNT(*) ' . $baseSql);
$cnt->execute($params);
$total = (int) $cnt->fetchColumn();
$pages = max(1, (int) ceil($total / $perPage));
$page  = min($pages, max(1, (int) (isset($_GET['page']) ? $_GET['page'] : 1)));
$offset = ($page - 1) * $perPage;

$stmt = $pdo->prepare('SELECT r.requested_at, c.name AS crop, d.name AS district, r.sector, v.name AS variety, r.found '
    . $baseSql . ' ORDER BY r.requested_at DESC, r.request_id DESC LIMIT ' . $perPage . ' OFFSET ' . $offset);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$crops     = all_crops();
$provinces = districts_by_province();

function page_link($page)
{
    $q = $_GET;
    $q['page'] = $page;
    unset($q['export']);
    return '?' . http_build_query($q);
}
$exportQuery = $_GET;
unset($exportQuery['page']);
$exportQuery['export'] = 'csv';

admin_header('Requests', 'requests');
?>
<form method="get" class="panel filters">
  <div class="filter-grid">
    <div>
      <label for="crop">Crop</label>
      <select id="crop" name="crop">
        <option value="0">All crops</option>
        <?php foreach ($crops as $c): ?>
          <option value="<?= (int) $c['crop_id'] ?>" <?= $crop === (int) $c['crop_id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label for="district">District</label>
      <select id="district" name="district">
        <option value="0">All districts</option>
        <?php foreach ($provinces as $province => $list): ?>
          <optgroup label="<?= e($province) ?>">
            <?php foreach ($list as $d): ?>
              <option value="<?= (int) $d['district_id'] ?>" <?= $district === (int) $d['district_id'] ? 'selected' : '' ?>><?= e($d['name']) ?></option>
            <?php endforeach; ?>
          </optgroup>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label for="found">Result</label>
      <select id="found" name="found">
        <option value="">Any</option>
        <option value="1" <?= $found === '1' ? 'selected' : '' ?>>Variety offered</option>
        <option value="0" <?= $found === '0' ? 'selected' : '' ?>>No variety found</option>
      </select>
    </div>
    <div>
      <label for="from">From</label>
      <input id="from" name="from" type="date" value="<?= e($from) ?>">
    </div>
    <div>
      <label for="to">To</label>
      <input id="to" name="to" type="date" value="<?= e($to) ?>">
    </div>
  </div>
  <div class="form-actions">
    <button class="btn btn-primary" type="submit">Apply filters</button>
    <a class="btn btn-ghost" href="<?= e(url('admin/requests.php')) ?>">Clear</a>
    <a class="btn btn-ghost push-right" href="?<?= e(http_build_query($exportQuery)) ?>">Download as CSV</a>
  </div>
</form>

<p class="muted result-count"><?= $total ?> <?= $total === 1 ? 'request' : 'requests' ?> found</p>

<?php if (!$rows): ?>
  <div class="panel empty-state"><h2>Nothing matches</h2><p>Try removing a filter.</p></div>
<?php else: ?>
<div class="panel table-wrap">
  <table class="table">
    <thead><tr><th>When</th><th>Crop</th><th>District</th><th>Sector</th><th>Variety offered</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= e(fmt_date($r['requested_at'])) ?></td>
        <td><?= e($r['crop']) ?></td>
        <td><?= e($r['district']) ?></td>
        <td><?= e($r['sector'] ?: '-') ?></td>
        <td><?= $r['found'] ? e($r['variety']) : '<span class="tag tag-warn">None</span>' ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php if ($pages > 1): ?>
<nav class="pager" aria-label="Pages">
  <?php if ($page > 1): ?><a href="<?= e(page_link($page - 1)) ?>">Previous</a><?php endif; ?>
  <span>Page <?= $page ?> of <?= $pages ?></span>
  <?php if ($page < $pages): ?><a href="<?= e(page_link($page + 1)) ?>">Next</a><?php endif; ?>
</nav>
<?php endif; ?>
<?php endif; ?>
<?php admin_footer(); ?>
