<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout_admin.php';
require_login();

$pdo = db();
$id  = (int) (isset($_GET['id']) ? $_GET['id'] : 0);

$levels = array('low', 'medium', 'high');
$v = array(
    'crop_id' => 0, 'name' => '', 'drought_tolerance' => 'high', 'expected_yield' => '',
    'maturity_days' => '', 'water_need' => 'low', 'notes' => '',
);
$selectedDistricts = array();

if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM varieties WHERE variety_id = ?');
    $stmt->execute(array($id));
    $existing = $stmt->fetch();
    if (!$existing) {
        flash('error', 'That variety no longer exists.');
        redirect('admin/varieties.php');
    }
    $v = array_merge($v, $existing);
    $sel = $pdo->prepare('SELECT district_id FROM variety_districts WHERE variety_id = ?');
    $sel->execute(array($id));
    $selectedDistricts = array_map('intval', $sel->fetchAll(PDO::FETCH_COLUMN));
}

$errors = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $v['crop_id']           = (int) (isset($_POST['crop_id']) ? $_POST['crop_id'] : 0);
    $v['name']              = trim(isset($_POST['name']) ? (string) $_POST['name'] : '');
    $v['drought_tolerance'] = isset($_POST['drought_tolerance']) ? (string) $_POST['drought_tolerance'] : '';
    $v['water_need']        = isset($_POST['water_need']) ? (string) $_POST['water_need'] : '';
    $v['expected_yield']    = trim(isset($_POST['expected_yield']) ? (string) $_POST['expected_yield'] : '');
    $v['maturity_days']     = trim(isset($_POST['maturity_days']) ? (string) $_POST['maturity_days'] : '');
    $v['notes']             = trim(isset($_POST['notes']) ? (string) $_POST['notes'] : '');
    $selectedDistricts      = array_map('intval', isset($_POST['districts']) && is_array($_POST['districts']) ? $_POST['districts'] : array());

    $cropExists = $pdo->prepare('SELECT 1 FROM crops WHERE crop_id = ?');
    $cropExists->execute(array($v['crop_id']));
    if (!$cropExists->fetchColumn()) {
        $errors[] = 'Choose a crop.';
    }
    if ($v['name'] === '' || text_len($v['name']) > 100) {
        $errors[] = 'Enter the variety name (up to 100 characters).';
    }
    if (!in_array($v['drought_tolerance'], $levels, true)) {
        $errors[] = 'Choose a drought tolerance level.';
    }
    if (!in_array($v['water_need'], $levels, true)) {
        $errors[] = 'Choose how much water the variety needs.';
    }
    if ($v['expected_yield'] !== '' && (!is_numeric($v['expected_yield']) || $v['expected_yield'] < 0 || $v['expected_yield'] > 9999)) {
        $errors[] = 'Expected yield must be a number such as 2.5 (tonnes per hectare).';
    }
    if ($v['maturity_days'] !== '' && (!ctype_digit($v['maturity_days']) || (int) $v['maturity_days'] > 1000)) {
        $errors[] = 'Days to harvest must be a whole number.';
    }

    if (!$errors) {
        $yield = $v['expected_yield'] === '' ? null : $v['expected_yield'];
        $days  = $v['maturity_days'] === '' ? null : (int) $v['maturity_days'];
        $notes = $v['notes'] === '' ? null : $v['notes'];

        $pdo->beginTransaction();
        try {
            if ($id) {
                $q = $pdo->prepare(
                    'UPDATE varieties SET crop_id=?, name=?, drought_tolerance=?, expected_yield=?,
                            maturity_days=?, water_need=?, notes=?, is_sample=0
                      WHERE variety_id=?'
                );
                $q->execute(array($v['crop_id'], $v['name'], $v['drought_tolerance'], $yield, $days, $v['water_need'], $notes, $id));
            } else {
                $q = $pdo->prepare(
                    'INSERT INTO varieties (crop_id, name, drought_tolerance, expected_yield, maturity_days, water_need, notes, created_by)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
                );
                $officer = current_officer();
                $q->execute(array($v['crop_id'], $v['name'], $v['drought_tolerance'], $yield, $days, $v['water_need'], $notes, $officer['officer_id']));
                $id = (int) $pdo->lastInsertId();
            }

            $pdo->prepare('DELETE FROM variety_districts WHERE variety_id = ?')->execute(array($id));
            if ($selectedDistricts) {
                $ins = $pdo->prepare('INSERT IGNORE INTO variety_districts (variety_id, district_id)
                                      SELECT ?, district_id FROM districts WHERE district_id = ?');
                foreach (array_unique($selectedDistricts) as $did) {
                    $ins->execute(array($id, $did));
                }
            }
            $pdo->commit();
        } catch (Exception $ex) {
            $pdo->rollBack();
            throw $ex;
        }

        flash('success', 'Variety saved.');
        redirect('admin/varieties.php');
    }
}

$crops     = all_crops();
$provinces = districts_by_province();
$isEdit    = $id > 0;

admin_header($isEdit ? 'Edit variety' : 'Add variety', 'varieties');
?>
<?php if ($errors): ?>
  <div class="notice notice-error" role="alert">
    <?php foreach ($errors as $msg): ?><div><?= e($msg) ?></div><?php endforeach; ?>
  </div>
<?php endif; ?>

<form method="post" class="panel form-panel" novalidate>
  <?= csrf_field() ?>

  <div class="form-grid">
    <div>
      <label for="crop_id">Crop</label>
      <select id="crop_id" name="crop_id" required>
        <option value="">Choose a crop</option>
        <?php foreach ($crops as $c): ?>
          <option value="<?= (int) $c['crop_id'] ?>" <?= (int) $v['crop_id'] === (int) $c['crop_id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label for="name">Variety name</label>
      <input id="name" name="name" type="text" maxlength="100" value="<?= e($v['name']) ?>" required>
    </div>
    <div>
      <label for="drought_tolerance">Drought tolerance</label>
      <select id="drought_tolerance" name="drought_tolerance">
        <?php foreach ($levels as $l): ?>
          <option value="<?= e($l) ?>" <?= $v['drought_tolerance'] === $l ? 'selected' : '' ?>><?= e(level_label($l)) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label for="water_need">Water needed</label>
      <select id="water_need" name="water_need">
        <?php foreach ($levels as $l): ?>
          <option value="<?= e($l) ?>" <?= $v['water_need'] === $l ? 'selected' : '' ?>><?= e(level_label($l)) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label for="expected_yield">Expected yield <span class="optional">(tonnes per hectare, optional)</span></label>
      <input id="expected_yield" name="expected_yield" type="text" inputmode="decimal" value="<?= e($v['expected_yield']) ?>" placeholder="2.5">
    </div>
    <div>
      <label for="maturity_days">Days to harvest <span class="optional">(optional)</span></label>
      <input id="maturity_days" name="maturity_days" type="text" inputmode="numeric" value="<?= e($v['maturity_days']) ?>" placeholder="75">
    </div>
  </div>

  <label for="notes">Notes for farmers <span class="optional">(optional)</span></label>
  <textarea id="notes" name="notes" rows="3"><?= e($v['notes']) ?></textarea>

  <fieldset class="district-picker">
    <legend>Where is this variety recommended?</legend>
    <p class="muted">Tick the districts it suits. Leave every box empty to recommend it in all districts.</p>
    <div class="picker-tools">
      <button type="button" class="btn btn-ghost btn-sm" data-check-all>Tick all</button>
      <button type="button" class="btn btn-ghost btn-sm" data-check-none>Clear</button>
    </div>
    <?php foreach ($provinces as $province => $list): ?>
      <div class="province">
        <h3><?= e($province) ?></h3>
        <div class="check-grid">
          <?php foreach ($list as $d): ?>
            <label class="check">
              <input type="checkbox" name="districts[]" value="<?= (int) $d['district_id'] ?>"
                     <?= in_array((int) $d['district_id'], $selectedDistricts, true) ? 'checked' : '' ?>>
              <span><?= e($d['name']) ?></span>
            </label>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </fieldset>

  <div class="form-actions">
    <button class="btn btn-primary" type="submit"><?= $isEdit ? 'Save changes' : 'Save variety' ?></button>
    <a class="btn btn-ghost" href="<?= e(url('admin/varieties.php')) ?>">Cancel</a>
  </div>
</form>
<?php admin_footer(); ?>
