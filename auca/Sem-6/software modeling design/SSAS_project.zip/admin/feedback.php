<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout_admin.php';
require_login();

$pdo = db();

$rows = $pdo->query(
    "SELECT f.created_at, f.outcome, f.comment, v.name AS variety, c.name AS crop, d.name AS district
       FROM feedback f
       LEFT JOIN recommendation_requests r ON r.request_id = f.request_id
       LEFT JOIN varieties v ON v.variety_id = f.variety_id
       LEFT JOIN crops c ON c.crop_id = r.crop_id
       LEFT JOIN districts d ON d.district_id = r.district_id
      ORDER BY f.created_at DESC, f.feedback_id DESC LIMIT 200"
)->fetchAll();

$labels = array('worked' => 'It worked', 'partly' => 'Worked partly', 'not_helpful' => 'Not helpful');
$tagClass = array('worked' => 'tag-near', 'partly' => 'tag-sample', 'not_helpful' => 'tag-warn');

admin_header('Feedback', 'feedback');
?>
<?php if (!$rows): ?>
  <div class="panel empty-state"><h2>No feedback yet</h2><p>Farmers can leave feedback at the bottom of their result page.</p></div>
<?php else: ?>
<div class="panel table-wrap">
  <table class="table">
    <thead><tr><th>When</th><th>Answer</th><th>Variety</th><th>Crop and district</th><th>Comment</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= e(fmt_date($r['created_at'])) ?></td>
        <td><span class="tag <?= e($tagClass[$r['outcome']]) ?>"><?= e($labels[$r['outcome']]) ?></span></td>
        <td><?= e($r['variety'] ?: '-') ?></td>
        <td><?= $r['crop'] ? e($r['crop'] . ', ' . $r['district']) : '-' ?></td>
        <td class="wrap"><?= e($r['comment'] ?: '') ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>
<?php admin_footer(); ?>
