<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout_admin.php';
require_login();

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    csrf_verify();
    $del = $pdo->prepare('DELETE FROM suppliers WHERE supplier_id = ?');
    $del->execute(array((int) $_POST['delete_id']));
    flash('success', 'Supplier deleted.');
    redirect('admin/suppliers.php');
}

$districtFilter = (int) (isset($_GET['district']) ? $_GET['district'] : 0);
$sql = "SELECT s.*, d.name AS district_name,
               (SELECT GROUP_CONCAT(v.name ORDER BY v.name SEPARATOR ', ')
                  FROM supplier_varieties sv JOIN varieties v ON v.variety_id = sv.variety_id
                 WHERE sv.supplier_id = s.supplier_id) AS stock
          FROM suppliers s JOIN districts d ON d.district_id = s.district_id";
$params = array();
if ($districtFilter) {
    $sql .= ' WHERE s.district_id = ?';
    $params[] = $districtFilter;
}
$sql .= ' ORDER BY d.name, s.name';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();
$provinces = districts_by_province();

admin_header('Suppliers', 'suppliers');
?>
<div class="toolbar">
  <form method="get" class="inline-form">
    <label for="district" class="sr-only">Filter by district</label>
    <select id="district" name="district" data-autosubmit>
      <option value="0">All districts</option>
      <?php foreach ($provinces as $province => $list): ?>
        <optgroup label="<?= e($province) ?>">
          <?php foreach ($list as $d): ?>
            <option value="<?= (int) $d['district_id'] ?>" <?= $districtFilter === (int) $d['district_id'] ? 'selected' : '' ?>><?= e($d['name']) ?></option>
          <?php endforeach; ?>
        </optgroup>
      <?php endforeach; ?>
    </select>
    <noscript><button class="btn btn-ghost" type="submit">Filter</button></noscript>
  </form>
  <a class="btn btn-primary" href="<?= e(url('admin/supplier_form.php')) ?>">Add supplier</a>
</div>

<?php if (!$rows): ?>
  <div class="panel empty-state"><h2>No suppliers here yet</h2><p>Add a supplier so farmers know where to get seed.</p></div>
<?php else: ?>
<div class="panel table-wrap">
  <table class="table">
    <thead><tr><th>Supplier</th><th>District</th><th>Location</th><th>Phone</th><th>Stocks</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><strong><?= e($r['name']) ?></strong><?php if ($r['is_sample']): ?> <span class="tag tag-sample">Sample</span><?php endif; ?></td>
        <td><?= e($r['district_name']) ?></td>
        <td><?= e($r['location'] ?: '-') ?></td>
        <td><?= e($r['phone'] ?: '-') ?></td>
        <td class="wrap"><?= e($r['stock'] ?: 'Nothing listed') ?></td>
        <td class="actions">
          <a href="<?= e(url('admin/supplier_form.php?id=' . (int) $r['supplier_id'])) ?>">Edit</a>
          <form method="post" data-confirm="Delete <?= e($r['name']) ?>?">
            <?= csrf_field() ?>
            <input type="hidden" name="delete_id" value="<?= (int) $r['supplier_id'] ?>">
            <button type="submit" class="link-danger">Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>
<?php admin_footer(); ?>
