<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout_admin.php';
require_login();

$pdo = db();

/* Delete a variety (POST only, with CSRF check) */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    csrf_verify();
    $del = $pdo->prepare('DELETE FROM varieties WHERE variety_id = ?');
    $del->execute(array((int) $_POST['delete_id']));
    flash('success', 'Variety deleted.');
    redirect('admin/varieties.php');
}

$cropFilter = (int) (isset($_GET['crop']) ? $_GET['crop'] : 0);
$sql = 'SELECT v.*, c.name AS crop_name,
               (SELECT COUNT(*) FROM variety_districts vd WHERE vd.variety_id = v.variety_id) AS district_count,
               (SELECT COUNT(*) FROM recommendation_requests r WHERE r.variety_id = v.variety_id) AS request_count
          FROM varieties v JOIN crops c ON c.crop_id = v.crop_id';
$params = array();
if ($cropFilter) {
    $sql .= ' WHERE v.crop_id = ?';
    $params[] = $cropFilter;
}
$sql .= ' ORDER BY c.name, v.name';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();
$crops = all_crops();

admin_header('Varieties', 'varieties');
?>
<div class="toolbar">
  <form method="get" class="inline-form">
    <label for="crop" class="sr-only">Filter by crop</label>
    <select id="crop" name="crop" data-autosubmit>
      <option value="0">All crops</option>
      <?php foreach ($crops as $c): ?>
        <option value="<?= (int) $c['crop_id'] ?>" <?= $cropFilter === (int) $c['crop_id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <noscript><button class="btn btn-ghost" type="submit">Filter</button></noscript>
  </form>
  <a class="btn btn-primary" href="<?= e(url('admin/variety_form.php')) ?>">Add variety</a>
</div>

<?php if (!$rows): ?>
  <div class="panel empty-state"><h2>No varieties here yet</h2><p>Add the first variety so farmers can receive advice.</p></div>
<?php else: ?>
<div class="panel table-wrap">
  <table class="table">
    <thead>
      <tr><th>Variety</th><th>Crop</th><th>Drought tolerance</th><th class="num">Yield</th><th class="num">Days</th><th>Districts</th><th class="num">Requests</th><th></th></tr>
    </thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td>
          <strong><?= e($r['name']) ?></strong>
          <?php if ($r['is_sample']): ?><span class="tag tag-sample">Sample</span><?php endif; ?>
        </td>
        <td><?= e($r['crop_name']) ?></td>
        <td><span class="tolerance-sm"><?= meter($r['drought_tolerance']) ?> <?= e(level_label($r['drought_tolerance'])) ?></span></td>
        <td class="num"><?= e($r['expected_yield'] === null ? '-' : fmt_yield($r['expected_yield'])) ?></td>
        <td class="num"><?= $r['maturity_days'] === null ? '-' : (int) $r['maturity_days'] ?></td>
        <td><?= (int) $r['district_count'] === 0 ? 'All districts' : (int) $r['district_count'] . ' districts' ?></td>
        <td class="num"><?= (int) $r['request_count'] ?></td>
        <td class="actions">
          <a href="<?= e(url('admin/variety_form.php?id=' . (int) $r['variety_id'])) ?>">Edit</a>
          <form method="post" data-confirm="Delete <?= e($r['name']) ?>? Farmers will no longer see it.">
            <?= csrf_field() ?>
            <input type="hidden" name="delete_id" value="<?= (int) $r['variety_id'] ?>">
            <button type="submit" class="link-danger">Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>
<?php admin_footer(); ?>
