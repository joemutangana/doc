<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout_admin.php';
require_login();

$pdo = db();
$id  = (int) (isset($_GET['id']) ? $_GET['id'] : 0);

$s = array('name' => '', 'phone' => '', 'location' => '', 'district_id' => 0);
$stocked = array();

if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM suppliers WHERE supplier_id = ?');
    $stmt->execute(array($id));
    $existing = $stmt->fetch();
    if (!$existing) {
        flash('error', 'That supplier no longer exists.');
        redirect('admin/suppliers.php');
    }
    $s = array_merge($s, $existing);
    $sel = $pdo->prepare('SELECT variety_id FROM supplier_varieties WHERE supplier_id = ?');
    $sel->execute(array($id));
    $stocked = array_map('intval', $sel->fetchAll(PDO::FETCH_COLUMN));
}

$errors = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $s['name']        = trim(isset($_POST['name']) ? (string) $_POST['name'] : '');
    $s['phone']       = trim(isset($_POST['phone']) ? (string) $_POST['phone'] : '');
    $s['location']    = trim(isset($_POST['location']) ? (string) $_POST['location'] : '');
    $s['district_id'] = (int) (isset($_POST['district_id']) ? $_POST['district_id'] : 0);
    $stocked          = array_map('intval', isset($_POST['varieties']) && is_array($_POST['varieties']) ? $_POST['varieties'] : array());

    $dExists = $pdo->prepare('SELECT 1 FROM districts WHERE district_id = ?');
    $dExists->execute(array($s['district_id']));

    if ($s['name'] === '' || text_len($s['name']) > 120) {
        $errors[] = 'Enter the supplier name (up to 120 characters).';
    }
    if (!$dExists->fetchColumn()) {
        $errors[] = 'Choose the district where the supplier is.';
    }
    if ($s['phone'] !== '' && !preg_match('/^[0-9 +()\-]{6,30}$/', $s['phone'])) {
        $errors[] = 'The phone number can only contain digits, spaces, + ( ) and -.';
    }
    if (text_len($s['location']) > 150) {
        $errors[] = 'The location is too long (150 characters at most).';
    }

    if (!$errors) {
        $phone    = $s['phone'] === '' ? null : $s['phone'];
        $location = $s['location'] === '' ? null : $s['location'];

        $pdo->beginTransaction();
        try {
            if ($id) {
                $q = $pdo->prepare('UPDATE suppliers SET name=?, phone=?, location=?, district_id=?, is_sample=0 WHERE supplier_id=?');
                $q->execute(array($s['name'], $phone, $location, $s['district_id'], $id));
            } else {
                $q = $pdo->prepare('INSERT INTO suppliers (name, phone, location, district_id) VALUES (?, ?, ?, ?)');
                $q->execute(array($s['name'], $phone, $location, $s['district_id']));
                $id = (int) $pdo->lastInsertId();
            }
            $pdo->prepare('DELETE FROM supplier_varieties WHERE supplier_id = ?')->execute(array($id));
            if ($stocked) {
                $ins = $pdo->prepare('INSERT IGNORE INTO supplier_varieties (supplier_id, variety_id)
                                      SELECT ?, variety_id FROM varieties WHERE variety_id = ?');
                foreach (array_unique($stocked) as $vid) {
                    $ins->execute(array($id, $vid));
                }
            }
            $pdo->commit();
        } catch (Exception $ex) {
            $pdo->rollBack();
            throw $ex;
        }
        flash('success', 'Supplier saved.');
        redirect('admin/suppliers.php');
    }
}

$provinces = districts_by_province();
$varieties = $pdo->query('SELECT v.variety_id, v.name, c.name AS crop FROM varieties v JOIN crops c ON c.crop_id = v.crop_id ORDER BY c.name, v.name')->fetchAll();
$byCrop = array();
foreach ($varieties as $v) {
    $byCrop[$v['crop']][] = $v;
}
$isEdit = $id > 0;

admin_header($isEdit ? 'Edit supplier' : 'Add supplier', 'suppliers');
?>
<?php if ($errors): ?>
  <div class="notice notice-error" role="alert">
    <?php foreach ($errors as $msg): ?><div><?= e($msg) ?></div><?php endforeach; ?>
  </div>
<?php endif; ?>

<form method="post" class="panel form-panel" novalidate>
  <?= csrf_field() ?>
  <div class="form-grid">
    <div>
      <label for="name">Supplier name</label>
      <input id="name" name="name" type="text" maxlength="120" value="<?= e($s['name']) ?>" required>
    </div>
    <div>
      <label for="district_id">District</label>
      <select id="district_id" name="district_id" required>
        <option value="">Choose a district</option>
        <?php foreach ($provinces as $province => $list): ?>
          <optgroup label="<?= e($province) ?>">
            <?php foreach ($list as $d): ?>
              <option value="<?= (int) $d['district_id'] ?>" <?= (int) $s['district_id'] === (int) $d['district_id'] ? 'selected' : '' ?>><?= e($d['name']) ?></option>
            <?php endforeach; ?>
          </optgroup>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label for="location">Location <span class="optional">(sector, trading centre or landmark)</span></label>
      <input id="location" name="location" type="text" maxlength="150" value="<?= e($s['location']) ?>">
    </div>
    <div>
      <label for="phone">Phone <span class="optional">(optional)</span></label>
      <input id="phone" name="phone" type="text" inputmode="tel" maxlength="30" value="<?= e($s['phone']) ?>" placeholder="07...">
    </div>
  </div>

  <fieldset class="district-picker">
    <legend>Varieties this supplier stocks</legend>
    <?php if (!$byCrop): ?>
      <p class="muted">There are no varieties yet. Add a variety first, then come back and tick it here.</p>
    <?php endif; ?>
    <?php foreach ($byCrop as $crop => $list): ?>
      <div class="province">
        <h3><?= e($crop) ?></h3>
        <div class="check-grid">
          <?php foreach ($list as $v): ?>
            <label class="check">
              <input type="checkbox" name="varieties[]" value="<?= (int) $v['variety_id'] ?>"
                     <?= in_array((int) $v['variety_id'], $stocked, true) ? 'checked' : '' ?>>
              <span><?= e($v['name']) ?></span>
            </label>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </fieldset>

  <div class="form-actions">
    <button class="btn btn-primary" type="submit"><?= $isEdit ? 'Save changes' : 'Save supplier' ?></button>
    <a class="btn btn-ghost" href="<?= e(url('admin/suppliers.php')) ?>">Cancel</a>
  </div>
</form>
<?php admin_footer(); ?>
