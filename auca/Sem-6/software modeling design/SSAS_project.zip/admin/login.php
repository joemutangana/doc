<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout_admin.php';

if (current_officer()) {
    redirect('admin/index.php');
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $email    = trim(isset($_POST['email']) ? (string) $_POST['email'] : '');
    $password = isset($_POST['password']) ? (string) $_POST['password'] : '';

    // Simple brake against guessing passwords: 5 wrong tries, then wait 60 seconds.
    $lockedUntil = isset($_SESSION['login_locked_until']) ? (int) $_SESSION['login_locked_until'] : 0;
    if ($lockedUntil > time()) {
        $error = 'Too many wrong attempts. Wait a minute and try again.';
    } else {
        $stmt = db()->prepare('SELECT officer_id, password_hash FROM officers WHERE email = ?');
        $stmt->execute(array($email));
        $row = $stmt->fetch();

        if ($row && password_verify($password, $row['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['officer_id'] = (int) $row['officer_id'];
            unset($_SESSION['login_fails'], $_SESSION['login_locked_until']);
            redirect('admin/index.php');
        }

        $_SESSION['login_fails'] = (isset($_SESSION['login_fails']) ? $_SESSION['login_fails'] : 0) + 1;
        if ($_SESSION['login_fails'] >= 5) {
            $_SESSION['login_locked_until'] = time() + 60;
            $_SESSION['login_fails'] = 0;
        }
        $error = 'The email or password is not correct.';
    }
}

auth_header('Officer login');
?>
    <h1>Officer login</h1>
    <p class="muted">For agriculture officers and administrators. Farmers do not need an account.</p>

    <?php if ($error): ?><div class="notice notice-error" role="alert"><?= e($error) ?></div><?php endif; ?>

    <form method="post" novalidate>
      <?= csrf_field() ?>
      <label for="email">Email</label>
      <input id="email" name="email" type="email" value="<?= e($email) ?>" autocomplete="username" required autofocus>

      <label for="password">Password</label>
      <input id="password" name="password" type="password" autocomplete="current-password" required>

      <button class="btn btn-primary btn-block" type="submit">Log in</button>
    </form>

    <p class="switch">New officer? <a href="<?= e(url('admin/signup.php')) ?>">Create an account</a></p>
<?php auth_footer(); ?>
