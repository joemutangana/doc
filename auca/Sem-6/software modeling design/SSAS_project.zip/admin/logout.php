<?php
require_once __DIR__ . '/../includes/bootstrap.php';

// Forget the officer, give the browser a fresh session id, then go to the login page.
unset($_SESSION['officer_id']);
session_regenerate_id(true);
flash('success', 'You are logged out.');
redirect('admin/login.php');
