<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/layout_admin.php';

if (current_officer()) {
    redirect('admin/index.php');
}

$errors = array();
$name   = '';
$email  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $name     = trim(isset($_POST['full_name']) ? (string) $_POST['full_name'] : '');
    $email    = trim(isset($_POST['email']) ? (string) $_POST['email'] : '');
    $password = isset($_POST['password']) ? (string) $_POST['password'] : '';
    $confirm  = isset($_POST['confirm']) ? (string) $_POST['confirm'] : '';
    $code     = trim(isset($_POST['code']) ? (string) $_POST['code'] : '');

    if ($name === '' || text_len($name) > 100) {
        $errors[] = 'Enter your full name.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || text_len($email) > 150) {
        $errors[] = 'Enter a valid email address.';
    }
    if (strlen($password) < 8) {
        $errors[] = 'The password must have at least 8 characters.';
    }
    if ($password !== $confirm) {
        $errors[] = 'The two passwords do not match.';
    }
    if (!hash_equals(SIGNUP_CODE, $code)) {
        $errors[] = 'The officer access code is not correct. Ask your administrator for it.';
    }

    if (!$errors) {
        $pdo = db();
        $exists = $pdo->prepare('SELECT 1 FROM officers WHERE email = ?');
        $exists->execute(array($email));
        if ($exists->fetchColumn()) {
            $errors[] = 'An account with this email already exists. Log in instead.';
        } else {
            // The very first account becomes the admin, everyone after is an officer.
            $count = (int) $pdo->query('SELECT COUNT(*) FROM officers')->fetchColumn();
            $role  = $count === 0 ? 'admin' : 'officer';

            $insert = $pdo->prepare('INSERT INTO officers (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)');
            $insert->execute(array($name, $email, password_hash($password, PASSWORD_DEFAULT), $role));

            session_regenerate_id(true);
            $_SESSION['officer_id'] = (int) $pdo->lastInsertId();
            flash('success', 'Welcome, ' . $name . '. Your ' . ($role === 'admin' ? 'admin' : 'officer') . ' account is ready.');
            redirect('admin/index.php');
        }
    }
}

auth_header('Create officer account');
?>
    <h1>Create officer account</h1>
    <p class="muted">You need the officer access code from your administrator.</p>

    <?php if ($errors): ?>
      <div class="notice notice-error" role="alert">
        <?php foreach ($errors as $msg): ?><div><?= e($msg) ?></div><?php endforeach; ?>
      </div>
    <?php endif; ?>

    <form method="post" novalidate>
      <?= csrf_field() ?>
      <label for="full_name">Full name</label>
      <input id="full_name" name="full_name" type="text" value="<?= e($name) ?>" maxlength="100" autocomplete="name" required autofocus>

      <label for="email">Email</label>
      <input id="email" name="email" type="email" value="<?= e($email) ?>" maxlength="150" autocomplete="username" required>

      <label for="password">Password <span class="optional">(at least 8 characters)</span></label>
      <input id="password" name="password" type="password" autocomplete="new-password" required>

      <label for="confirm">Repeat password</label>
      <input id="confirm" name="confirm" type="password" autocomplete="new-password" required>

      <label for="code">Officer access code</label>
      <input id="code" name="code" type="password" autocomplete="off" required>

      <button class="btn btn-primary btn-block" type="submit">Create account</button>
    </form>

    <p class="switch">Already have an account? <a href="<?= e(url('admin/login.php')) ?>">Log in</a></p>
<?php auth_footer(); ?>
